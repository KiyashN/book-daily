import React, { useState } from 'react';
import './LoginForm.css';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

function LoginForm() {
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    if (id === 'email') {
      setEmail(value);
    } else if (id === 'password') {
      setPassword(value);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Email:', email, 'Password:', password);
    navigate('/my-library');
  };

  return (
    <div className="form">
      <div className="form-header">
        <h2>Login</h2>
        <p>~Get in your library~</p>
      </div>
      <form onSubmit={handleSubmit}>
        <div className="email">
          <label className="form__label" htmlFor="email">
            Email
          </label>
          <input
            type="email"
            id="email"
            className="form__input"
            value={email}
            onChange={handleInputChange}
            placeholder="Email"
          />
        </div>
        <div className="password">
          <label className="form__label" htmlFor="password">
            Password
          </label>
          <input
            className="form__input"
            type="password"
            id="password"
            value={password}
            onChange={handleInputChange}
            placeholder="Password"
          />
        </div>
        <div className="footer">
          <button type="submit" className="btn">
            Log In
          </button>
        </div>
        <div className="form-footer">
          <p>
            Don't have an account?<Link to="/register"> Register now</Link>
          </p>
        </div>
      </form>
    </div>
  );
}

export default LoginForm;
