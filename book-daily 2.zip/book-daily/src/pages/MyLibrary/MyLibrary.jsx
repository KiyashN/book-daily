import React, { useState } from 'react';
import "./MyLibrary.css";
import MyLibraryImg from "../../images/mylibrary-img.jpg";
import { FaArrowLeft } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';

const MyLibrary = () => {
  const navigate = useNavigate();

  const [read, setReadBooks] = useState([]);
  const [reading, setReadingBooks] = useState([]);
  const [planned, setPlannedBooks] = useState([]);
  const [newBookTitle, setNewBookTitle] = useState("");

  const addBook = (list, book) => {
    const newBook = { id: list.length + 1, title: book.title };
    
    if (list === "read") {
      setReadBooks([...read, newBook]);
    } else if (list === "reading") {
      setReadingBooks([...reading, newBook]);
    } else if (list === "planned") {
      setPlannedBooks([...planned, newBook]);
    }

    setNewBookTitle("");
  };

  // const updateBookStatus = (list, bookId, newStatus) => {
  //   const updatedList = list.map(book => {
  //     if (book.id === bookId) {
  //       return { ...book, status: newStatus };
  //     }
  //     return book;
  //   });
  
  //   if (list === read) {
  //     setReadBooks(updatedList);
  //   } else if (list === reading) {
  //     setReadingBooks(updatedList);
  //   } else if (list === planned) {
  //     setPlannedBooks(updatedList);
  //   }
  // };
  
  const removeBook = (list, bookId) => {
    const filteredList = list.filter(book => book.id !== bookId);
  
    if (list === read) {
      setReadBooks(filteredList);
    } else if (list === reading) {
      setReadingBooks(filteredList);
    } else if (list === planned) {
      setPlannedBooks(filteredList);
    }
  };

  return (
    <section className='library'>
      <div className='container'>
        <div className='section-title'>
          <button type='button' className='flex flex-c back-btn' onClick={() => navigate("/book")}>
            <FaArrowLeft size={22} />
            <span className='fs-18 fw-6'>Go Back</span>
          </button>
        </div>

        <div className='library-content grid'>
          <div className='library-img'>
            <img src={MyLibraryImg} alt="Sorry not found" />
          </div>
          <div className='library-text'>
            <h2 className='library-title fs-26 ls-1'>My Library</h2>
            <div>
              <input
                type="text"
                value={newBookTitle}
                onChange={(e) => setNewBookTitle(e.target.value)}
                placeholder="Enter book title"
              />
            </div>

            <div>
              <h3>Already Read</h3>
              <ul>
                {read.map(book => (
                  <li key={book.id}>{book.title}
                    {/* <button onClick={() => updateBookStatus(reading, book.id, "read")}>
                     edit
                    </button> */}
                      <button onClick={() => removeBook(read, book.id)}>Delete</button>
                  </li>
                ))}
              </ul>
              <button onClick={() => addBook("read", { title: newBookTitle })}>
                Add to Already Read
              </button>
            </div>

            <div>
              <h3>Reading</h3>
              <ul>
                {reading.map(book => (
                  <li key={book.id}>{book.title}
                    <button onClick={() => removeBook(reading, book.id)}>Delete</button>
                  </li>
                ))}
              </ul>
              <button onClick={() => addBook("reading", { title: newBookTitle })}>
                Add to Reading
              </button>
            </div>

            <div>
              <h3>Planned</h3>
              <ul>
                {planned.map(book => (
                  <li key={book.id}>{book.title}
                    <button onClick={() => removeBook(planned, book.id)}>Delete</button>
                  </li>
                ))}
              </ul>
              <button onClick={() => addBook("planned", { title: newBookTitle })}>
                Add to Planned
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default MyLibrary;
